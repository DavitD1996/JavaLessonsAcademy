package MyProject;

public class Main {
    public static void main(String[] args) {
     Student s1=new Student("John",13,"male");
     Student s2=new Student("Jero",13,"male");
     Teacher t1=new Teacher("vardan",20,"male");
     s1.print();
     s2.print();
    }
}
